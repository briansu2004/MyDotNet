namespace Play.Catalog.Service.Settings
{
    public class RabbitMQSettings
    {
        public string Host { get; init; }
    }
}