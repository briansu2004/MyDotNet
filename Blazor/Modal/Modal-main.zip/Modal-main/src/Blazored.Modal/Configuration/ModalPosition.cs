﻿namespace Blazored.Modal;

public enum ModalPosition
{
    Center,
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
    Custom
}